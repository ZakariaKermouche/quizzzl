package com.company;
public class Question_noti
{
    private int nombre;
    private Notion no;


    public Question_noti( Notion n, int nom)
    { this.no=n;
        this.nombre=nom;
    }

    public int getNombre()
    {
        return this.nombre;
    }

    public Notion getNotion()
    {
        return this.no;
    }


}
