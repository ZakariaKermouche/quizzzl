package com.company;
import java.util.*;
public class Apprenant extends Compte
{
    private String nom;
    private String prenom;
    private String dat_naiss;
    private String adresse;
    private float note;
    public Apprenant(String n, String p, String dt, String a)
    {
        super((p.charAt(0)+n),(n+dt));
        this.nom=n;
        this.prenom=p;
        this.dat_naiss=dt;
        this.adresse=a;
        this.note=note;
    }
    public void setL(String l)
    {
        super.setL(l);
    }
    public void setP(String l)
    {
        super.setP(l);
    }
    public void setnote(float n)
    {
        this.note = n;
    }
    public float getnote()
    {
        return this.note;
    }
    public String getnom()
    {
        return this.nom;
    }
    public void afficher()
    {

        System.out.println("Le login : "+this.getL()+"\ne mot de passe: "+this.getP());
    }

    public int compareTo(Object o)
    {
        Apprenant a = (Apprenant)o;
        if (this.note<a.note)
        {return -1;}
        else if(this.note>a.note)
        {return 1;}
        else
        {return 0;}
    }

}
