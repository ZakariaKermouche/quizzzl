package com.company;
import java.util.*;
public abstract class Question
{
    protected String question;
    private Notion n;

    public Question(String q,Notion n)
    {this.question=q;
        this.n=n;
        this.n.add_question(this);
    }
    public void setQ(String q)
    {this.question=q;}

    public String getQ() {
        return question;
    }

    public void afficher()
    {String s="La question est : "+this.question;
        System.out.println(s);}
    public Notion getN()
    {
        return this.n;
    }
    public abstract float evaluer(ArrayList<String> rep);

}
