package com.company;
import java.util.*;
public class Qo extends Question
{
    private ArrayList<String> tab_rep = new ArrayList<String>();


    public Qo(String s,Notion n,String rep[])
    {super(s,n);
        for (int i=0; i<rep.length;i++)
        {
            tab_rep.add(rep[i]);
        }}

    public void add_rep(String y)
    {
        tab_rep.add(y);
    }
    public void afficher()
    {System.out.println("Qo:");
        super.afficher();
    }
    public float evaluer(ArrayList<String> rep)
    {

        if (tab_rep.contains(rep.get(1))) {
            return 100;}
        else {return 0;}
    }
}

