package com.company;
import java.util.*;

public class Quiz
{
    private String nom;
    private String dt_ouv;
    private String dt_exp;
    private ArrayList<Question_noti> nb_quest_not = new ArrayList<Question_noti>();
    private ArrayList<Question> tab_q = new ArrayList<Question>();
    private static int nbre_quest = 0;

    public Quiz(String n,String dt1, String dt2,Question_noti qn[])
    {
        this.nom=n;
        this.dt_ouv=dt1;
        this.dt_exp=dt2;
        int nb = 0;
        for (int i=0; i<qn.length;i++)
        {
            nb_quest_not.add(qn[i]);
        }
        for (int j=0; j<nb_quest_not.size(); j++)
        {
            int k= nb_quest_not.get(j).getNombre();
            Notion n1= nb_quest_not.get(j).getNotion();
            ArrayList<Question> q= n1.get_listQ(k);
            nb += q.size();
            for(int l=0;l<q.size();l++)
            {
                this.tab_q.add(q.get(l));
            }
        }
        this.nbre_quest=nb;
    }

    public void afficher()
    {
        System.out.println("Nom : "+this.nom+"  Date d'ouverture: "+dt_ouv+"  Date d'expiration: "+dt_exp);
        for(int i=0; i<this.tab_q.size(); i++)
        {
            this.tab_q.get(i).afficher();
        }
    }
    public void setNom(String n)
    {
        this.nom=n;
    }
    public void setDt_ouv(String n)
    {
        this.dt_ouv=n;
    }
    public void setDt_exp(String n)
    {
        this.dt_exp=n;
    }
    public void removeQ(Question q)
    {
        this.tab_q.remove(q);
    }
    public void addQ(Notion n)
    { int i=getRandomNumberInRange(0,n.get_listQ().size()-1);
        while(tab_q.contains(n.get_listQ().get(i)))
        {i=getRandomNumberInRange(0,n.get_listQ().size()-1); }
        this.tab_q.add(n.get_listQ().get(i));
    }
    public void changeQ(Question q)
    {
        Notion n= q.getN();
        this.addQ(n);
        this.tab_q.remove(q);
    }

    private int getRandomNumberInRange(int min, int max) {

        if (min >= max) {
            throw new IllegalArgumentException("max must be greater than min");
        }

        Random r = new Random();
        return r.nextInt((max - min) + 1) + min;
    }
    public Question getQ(int i)
    {
        return tab_q.get(i);
    }
    public int getnbre_quest()
    {
        return nbre_quest;
    }
}
