package com.company;

public class Formateur extends Compte
{
    private Formation f;

    public Formateur(String s, String h, Formation t )
    {
        super(s,h);
        f=t;
    }

    public void ajout_app(Apprenant a)
    {f.add_apprenant(a);}

    public void supp_app(Apprenant a)
    {f.remove_apprenant(a);}
    public void majL(Apprenant a,String l)
    {a.setL(l);}
    public void majP(Apprenant a,String l)
    {a.setP(l);}
    public void sauvegareder_quiz(Quiz q)
    {
        this.f.add_quiz(q);
    }
}