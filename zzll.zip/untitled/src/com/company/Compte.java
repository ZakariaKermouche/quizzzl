package com.company;
public class Compte
{
    private String login;
    private String password;


    public Compte(String s,String h)
    {
        login=s;
        password=h;
    }

    public void setL(String l)
    {
        login=l;
    }

    public void setP(String l)
    {
        password=l;
    }
    public String getL()
    {
        return this.login;
    }

    public String getP()
    {
        return this.password;
    }
   /*public void connect(String l, String p)
   {
       if ()
       {
        }
   }*/
}
