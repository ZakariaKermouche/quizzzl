package com.company;

import java.util.*;           // for Arrays and Random
public class Main
{
    public static void main(String [] args)
    {
            /**************Creer Formation**************/
            Formation bac = new Formation("POO","Initiation Ã  la POO","20/01/2019","18/07/2019");
            /**************Creer Formateur**************/
            Formateur form = new Formateur("prof","esi2018",bac);
            /**************Creer Apprenants**************/
            Apprenant a1 = new Apprenant("zzl","krmch","151515","vjjf");
            Apprenant a2 = new Apprenant("frg","rzg","161616","eger");
            Apprenant a3 = new Apprenant("bin","mrghn","171717","qrgv");
            Apprenant a4 = new Apprenant("ch9","hd","181818","egzr'");
            form.ajout_app(a1);
            form.ajout_app(a2);
            form.ajout_app(a3);
            form.ajout_app(a4);
            System.out.println("**************Afficher Liste Apprenant**************/");
            bac.afficher_app();
            /*************Supprimer Apprenant***************/
            form.supp_app(a4);
            System.out.println("**************Afficher liste Apprenant après Suppressiond'un apprenant**************/");
            bac.afficher_app();/*************MÃ j Login***************/
            form.majL(a3,"etudiant3");
            System.out.println("**************Afficher liste Apprenant après changement login d'apprenant**************/");
            bac.afficher_app();
            /*************MÃ j Mdp***************/
            form.majP(a2,"esi2000");
            System.out.println("**************Afficher liste Apprenant après changement MdP**************/");
            bac.afficher_app();
            /**************Création de notions**********************/
            Notion n1= new Notion("Math");
            Notion n2= new Notion("Anglais");
            String f1[]={"25","16"};
            String c1[]={"1","-1"};
            /********************Ajout qcm à notion math*********************************/
            Qcm q1= new Qcm ("xÂ²=1, x=?", n1,c1,f1);
            String f2[]= {"77","46815","78"};
            String c2="10";
            /********************Ajout qcu à notion math*********************************/
            Qcu q2= new Qcu ("5*2=?",n1,c2,f2);
            String rep[] = {"4","quatre","four"};
            /********************Ajout qo à notion math*********************************/
            Qo q3= new Qo ("sqrt(16)=?",n1,rep);
            String f3[]={"Bad","No"};
            String c3[]={"Fine","Nice"};
            /********************Ajout qcm à notion anglais*********************************/
            Qcm q4= new Qcm("How are you?",n2,c3,f3);
            String f4[]={"a thing","a human","Mbolhi"};
            String c4="An animal";
            /********************Ajout qcu à notion anglais*********************************/
            Qcu q5= new Qcu("What is a horse?",n2,c4,f4);
            Question_noti qn1= new Question_noti(n1,2);//nbadal hadoo
            Question_noti qn2= new Question_noti(n2,2);//
            Question_noti qn []= {qn1,qn2};
            /********************Création d'un quiz avec les notions introduites*******************************/
            Quiz quizzzl = new Quiz("quizzzl","23/06/2019","24/06/2019",qn);
            bac.add_notion(n1);
            bac.add_notion(n2);
            System.out.println("/****************************************/");
            System.out.println("/****************************************/");
            quizzzl.afficher();
            quizzzl.setNom("quizzwi");
            quizzzl.setDt_ouv("25/06/2019");
            quizzzl.setDt_exp("25/02/2022");
            System.out.println("/****************************************/");
            System.out.println("/***********Affichage après modification nom, date ouverture et fin du quiz****************/");
            quizzzl.afficher();
            quizzzl.addQ(n1);
            System.out.println("/***********Affichage après ajout d'une question dans une notion*****************************/");
            quizzzl.afficher();
            quizzzl.removeQ(q1);
            System.out.println("/***********Affichage après suppression d'une question*****************************/");
            quizzzl.afficher();
            System.out.println("/****************************************/");        System.out.println("/****************************************/");
            /******************quest_rep*******************/
            ArrayList<ArrayList<String>> rep1= new ArrayList<ArrayList<String>>();
            ArrayList<String> rep_qcm = new ArrayList<String>();
            ArrayList<String> rep_qo = new ArrayList<String>();
            ArrayList<String> rep_qcu = new ArrayList<String>();
            ArrayList<String> rep_qcuz = new ArrayList<String>();
            rep_qcm.add("How are you?");
            rep_qcm.add("Fine");
            rep_qcm.add("Nice");
            /////////////////////////
        /*rep_qcm1.add("xÂ²=1, x=?");
        rep_qcm1.add("-1");*/
            //rep_qcm1.add("1");
            /////////////////////////
            rep_qo.add("sqrt(16)=?");
            rep_qo.add("4");
            /////////////////////////
            rep_qcu.add("5*2=?");
            rep_qcu.add("1");
            /////////////////////////
            rep_qcuz.add("What is a horse?");
            rep_qcuz.add("An animal");
            /////////////////////////
            rep1.add(rep_qcm);
            rep1.add(rep_qcu);
            rep1.add(rep_qo);
            float score = 0;
        /*score += q4.evaluer(rep_qcm);
        score += q2.evaluer(rep_qcu);
        score += q3.evaluer(rep_qo);*/
            System.out.println("/*******exemple de quiz non accomplie:******/");
            Quiz_rep qzz= new Quiz_rep(quizzzl,rep1);
            if (qzz.gettaux_accomplissement() == 100)
            {
                qzz.evaluation();
                System.out.println(qzz.getnote());
            }
            else
            {
                System.out.println("Le quiz n'est pas encore accomplie!!, il vous reste "+(100-qzz.gettaux_accomplissement())+"%");
            }
            System.out.println("/*******************************************/");
            //rep1.add(rep_qcu1);
            rep1.add(rep_qcuz);
            Quiz_rep qzz1= new Quiz_rep(quizzzl,rep1);
            System.out.println("/*******exemple de quiz accomplie:******/");
            if (qzz1.gettaux_accomplissement() == 100)
            {
                qzz1.evaluation();
                //System.out.println("Votre note est "+qzz1.getnote());
                a1.setnote(qzz1.getnote());
            }
            else
            {
                System.out.println("Le quiz n'est pas encore accomplie!!, il vous reste "+(100-qzz.gettaux_accomplissement())+"%");
            }
            System.out.println("/*******************************************/");
            //System.out.println(score);
            //bac.add_quiz(quizzzl);



            ArrayList<ArrayList<String>> rep2= new ArrayList<ArrayList<String>>();
            //ArrayList<String> rep_qcm = new ArrayList<String>();
            ArrayList<String> rep_qcm1 = new ArrayList<String>();
            ArrayList<String> rep_qo1 = new ArrayList<String>();
            ArrayList<String> rep_qcue = new ArrayList<String>();
            ArrayList<String> rep_qcu1 = new ArrayList<String>();
            rep_qcm1.add("How are you?");
            rep_qcm1.add("Fine");
            /////////////////////////
            rep_qo1.add("sqrt(16)=?");
            rep_qo1.add("4");
            /////////////////////////
            rep_qcu1.add("5*2=?");
            rep_qcu1.add("1");
            /////////////////////////
            rep_qcue.add("What is a horse?");
            rep_qcue.add("An animal");
            /////////////////////////
            rep2.add(rep_qcm1);
            rep2.add(rep_qcue);
            rep2.add(rep_qo1);
            rep2.add(rep_qcu1);
            Quiz_rep qzwi= new Quiz_rep(quizzzl,rep2);
            if (qzwi.gettaux_accomplissement() == 100)
            {
                qzwi.evaluation();
                //System.out.println(qzwi.getnote());
                a2.setnote(qzwi.getnote());
            }
            else
            {
                System.out.println("Le quiz n'est pas encore accomplie!!, il vous reste "+(100-qzwi.gettaux_accomplissement())+"%");
            }

            ArrayList<ArrayList<String>> rep3= new ArrayList<ArrayList<String>>();
            //ArrayList<String> rep_qcm = new ArrayList<String>();
            ArrayList<String> rep_qcm2 = new ArrayList<String>();
            ArrayList<String> rep_qo2 = new ArrayList<String>();
            ArrayList<String> rep_qcur = new ArrayList<String>();
            ArrayList<String> rep_qcu2 = new ArrayList<String>();
            rep_qcm2.add("How are you?");
            rep_qcm2.add("Fine");
            rep_qcm2.add("Nice");
            rep_qcm2.add("Bad");
            /////////////////////////
        /*rep_qcm1.add("xÂ²=1, x=?");
        rep_qcm1.add("-1");*/
            //rep_qcm1.add("1");
            /////////////////////////
            rep_qo2.add("sqrt(16)=?");
            rep_qo2.add("4");
            /////////////////////////
            rep_qcu2.add("5*2=?");
            rep_qcu2.add("10");
            /////////////////////////
            rep_qcur.add("What is a horse?");
            rep_qcur.add("An animal");
            /////////////////////////
            rep3.add(rep_qcm2);
            rep3.add(rep_qcur);
            rep3.add(rep_qo2);
            rep3.add(rep_qcu2);
            Quiz_rep qzo= new Quiz_rep(quizzzl,rep3);
            if (qzo.gettaux_accomplissement() == 100)
            {
                qzo.evaluation();
                a3.setnote(qzo.getnote());
                //System.out.println(qzo.getnote());
            }
            else
            {
                System.out.println("Le quiz n'est pas encore accomplie!!, il vous reste "+(100-qzo.gettaux_accomplissement())+"%");
            }
            System.out.println("/*******************************************/");
            //bac.classement();

        }

    }