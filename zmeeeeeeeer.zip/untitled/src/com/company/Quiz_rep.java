package com.company;
import java.util.*;
public class Quiz_rep
{
    private Quiz q;
    private ArrayList<ArrayList<String>> rep= new ArrayList<ArrayList<String>>();
    private float taux_accomplissement;
    private float note;


    public Quiz_rep(Quiz qz,ArrayList<ArrayList<String>> rp)
    {
        this.q=qz;
        for(int i=0; i<rp.size(); i++)
        {
            this.rep.add(rp.get(i));
        }
        this.taux_accomplissement=(float)rp.size()/q.getnbre_quest()*100;
        this.note = note;
        //System.out.println(q.getnbre_quest());
    }

    public float getnote()
    {
        return this.note;
    }
    public float gettaux_accomplissement()
    {
        return taux_accomplissement;
    }
    public void evaluation()
    {
        int score=0;
        for (int i=0; i<this.rep.size(); i++)
        {
            int j =0;
            while((this.rep.get(j).get(0)!=q.getQ(i).getQ()) &&(j<this.rep.size())){j++;}
            score+=q.getQ(i).evaluer((rep.get(j)));
        }
        this.note = score/rep.size();
    }

}
