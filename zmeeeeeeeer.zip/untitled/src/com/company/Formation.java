package com.company;
import java.util.*;
public class Formation
{
    private String nom;
    private String description;
    private String dat_db;
    private String dat_fn;
    private ArrayList<Notion> tab_notion = new ArrayList<Notion>();
    private ArrayList<Quiz> tab_quiz = new ArrayList<Quiz>();
    private ArrayList<Formateur> tab_formateur = new ArrayList<Formateur>();
    private ArrayList<Apprenant> tab_apprenant = new ArrayList<Apprenant>();

    public Formation(String n, String d, String d1, String d2)
    {
        this.nom=n;
        this.description=d;
        this.dat_db=d1;
        this.dat_fn=d2;
    }
    public void add_notion(Notion n)
    {
        this.tab_notion.add(n);
    }
    public void add_quiz(Quiz q)
    {
        this.tab_quiz.add(q);
    }
    public void add_formateur(Formateur n)
    {
        this.tab_formateur.add(n);
    }
    public void add_apprenant(Apprenant n)
    {
        this.tab_apprenant.add(n);
    }
    public void remove_apprenant(Apprenant n)
    {
        this.tab_apprenant.remove(n);
    }

    public String afficher_app()
    {
        String aff = "\n";
        for(int i=0;i<tab_apprenant.size();i++)
        {
            aff += tab_apprenant.get(i).afficher();

        }
        return aff;
    }
    public ArrayList<Notion> get_Notions(){

        return tab_notion;
    }

    public ArrayList<Quiz> get_Quiz(){

        return tab_quiz;
    }

    public void classement()
    {
        Collections.sort(tab_apprenant,Collections.reverseOrder());
        for (int i = 0;i<tab_apprenant.size();i++){
            System.out.println("Nom : "+tab_apprenant.get(i).getnom()+", note : "+tab_apprenant.get(i).getnote()+"%" );
        }
    }
}
