package com.company;
import java.util.*;
public class Notion
{
    private String nom;
    private ArrayList<Question> tabQ = new ArrayList<Question>();

    public Notion(String n)
    {
        this.nom=n;
    }

    public String getNom() {
        return nom;
    }

    public void add_question(Question Q)
    {
        tabQ.add(Q);
    }

    public void remove_question(Question Q)
    {
        tabQ.remove(Q);
    }

    public void setNom(String n)
    {
        this.nom=n;
    }
    public ArrayList<Question> get_listQ(int i)
    {
        ArrayList<Question> l = new ArrayList<Question>();
        this.tabQ=shuffle(this.tabQ);
        int j=0;
        while(j<i)
        {
            l.add(tabQ.get(j)); j++;
        }
        return l;
    }
    public ArrayList<Question> get_listQ()
    {
        ArrayList<Question> l = this.tabQ;
        return l;
    }
    public void afficher()
    {
        for (int i=0; i<tabQ.size(); i++)
        {
            tabQ.get(i).afficher();
        }
    }
    public ArrayList<Question> shuffle(ArrayList<Question> marks)
    {
        Random rand = new Random();
        Collections.shuffle(marks);
        return marks;

    }
}
