package com.company;
import java.util.*;

public class Qcu extends Question
{
    private String rep;
    private ArrayList<String> tab_faux = new ArrayList<String>();
    private ArrayList<String> tab_rep = new ArrayList<String>();


    public Qcu(String s1,Notion n,String s2,String r[])
    {
        super(s1,n);
        this.rep=s2; //{"math","1+1=","2","3","4","5","5*2=","10"}
        for (int i=0; i<r.length;i++)
        {
            tab_faux.add(r[i]);
        }

        tab_rep= this.repondre();
    }

    public void add_faux(String y)
    {
        tab_faux.add(y);
    }

    public ArrayList<String> repondre()
    {
        ArrayList<String> f= new ArrayList<String>(); int i=0;

        while(i<tab_faux.size())
        {f.add(this.tab_faux.get(i));
            i++;
        }
        f.add(rep);
        f=shuffle(f);
        return f;
    }

    public String afficher()
    {    String aff;
        aff=("\nQcu : "+super.afficher());
        aff+="\nLes réponses: \n"; int i=1;
        while(i<tab_rep.size()+1)
        {aff+=+i+"- "+tab_rep.get(i-1)+"\n";i++;}
        return aff;

    }


    public ArrayList<String> shuffle(ArrayList<String> marks)
    {
        Random rand = new Random();
        ArrayList <String>mylist= marks;
        Collections.shuffle(mylist);
        return mylist;
    }
    public float evaluer(ArrayList<String> reponse)
    {


        if (rep == reponse.get(1) )
        {   return 100;
        }
        else
        {   return 0;
        }
    }
}
