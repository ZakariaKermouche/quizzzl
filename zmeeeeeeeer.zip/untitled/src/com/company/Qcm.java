package com.company;
import java.util.*;
public class Qcm extends Question
{
    private ArrayList<String> tab_corct = new ArrayList<String>();
    private ArrayList<String> tab_faux = new ArrayList<String>();
    private ArrayList<String> tab_rep = new ArrayList<String>();

    public Qcm(String s,Notion n, String s2[], String s3[])
    {
        super(s,n);
        for (int i=0; i<s2.length;i++)
        {
            tab_corct.add(s2[i]);
        }
        for (int i=0; i<s3.length;i++)
        {
            tab_faux.add(s3[i]);
        }
        tab_rep = this.repondre();
    }

    public void add_corct(String y)
    {
        tab_corct.add(y);
    }
    public void add_faux(String y)
    {
        tab_faux.add(y);
    }

    public ArrayList<String> repondre()
    {
        ArrayList<String> f= new ArrayList<String>(); int i=0;

        while(i<tab_faux.size())
        {f.add(this.tab_faux.get(i));
            i++;
        }
        i=0;
        while(i<tab_corct.size())
        {f.add(this.tab_corct.get(i));
            i++;
        }
        //f=shuffle(f);
        return f;
    }

    public String afficher()
    {   String aff;
        aff=("\nQcm : "+super.afficher());
        aff+="Les réponses: \n"; int i=1;
        while(i<tab_rep.size()+1)
        {aff+=+i+"- "+tab_rep.get(i-1)+"\n";i++;}
        return aff;

    }


    public ArrayList<String> shuffle(ArrayList<String> marks)
    {
        Random rand = new Random();
        Collections.shuffle(marks);
        return marks;
    }
    public float evaluer(ArrayList<String> rep)
    {
        float score = 0;
        for(int i=1; i<rep.size();i++)
        {
            if (this.tab_corct.contains(rep.get(i)))
            {
                score++;
                //System.out.println("crct");
            }
            else
            {
                score--;
                //System.out.println("flz");
            }
        }
        ArrayList<String> zzl = new ArrayList<String>();
        for(int i=1;i < rep.size();i++)
        {
            zzl.add((rep.get(i)));
        }

        for (int i = 0;i<tab_corct.size();i++)
        {
            if(!zzl.contains(tab_corct.get(i)))
            {
                score--;
                //System.out.println("cntyn crct");
            }
        }
        for (int i = 0; i<tab_faux.size();i++)
        {
            if(!zzl.contains(tab_faux.get(i)))
            {
                score++;
                //System.out.println("cntyn flz");
            }
        }

        score = (score*100)/tab_rep.size();
        if (score<0)
        {return 0;}
        else
        {return score;}
    }


}
