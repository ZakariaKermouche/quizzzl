package GUI;

import com.company.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class AcceuilFormateur implements Initializable {

    @FXML public ListView notionlv;
    @FXML public TextField nouv_notion;
    @FXML public ListView quizlv;
    @FXML public TextField nomquiz;
    @FXML public TextField datedb;
    @FXML public TextField datefn;
    @FXML public ChoiceBox nbmath;
    @FXML public ChoiceBox nbeng;
    @FXML public TextArea affichquiz;
    @FXML public TextField nom_app;
    @FXML public TextField prenom_app;
    @FXML public TextField adresse_app;
    @FXML public TextField date_naiss_app;
    @FXML public TextArea app_afficher;



    Formation bac = new Formation("BAC","Cours révision de BAC","20/01/2019","18/07/2019");
    Formateur form = new Formateur("admin","admin123",bac);
    Apprenant a1 = new Apprenant("Kermouche","Zakaria","30/06/1999","hz_kermouche@esi.dz");
    Apprenant a2 = new Apprenant("Rezgui","Abdelkader","13/12/1999","ha_rezgui@esi.dz");
    Notion n1= new Notion("Math");
    Notion n2= new Notion("Anglais");
    String f1[]={"25","16"};
    String c1[]={"1","-1"};
    Qcm q1= new Qcm ("x²=1, x=?", n1,c1,f1);
    String f2[]= {"77","46815","78"};
    String c2="10";
    Qcu q2= new Qcu ("5*2=?",n1,c2,f2);
    String rep[] = {"4","quatre","four"};
    Qo q3= new Qo ("sqrt(16)=?",n1,rep);
    String f3[]={"Bad","No"};
    String c3[]={"Fine","Nice"};
    Qcm q4= new Qcm("How are you?",n2,c3,f3);
    String f4[]={"a thing","a human","Mbolhi"};
    String c4="An animal";
    Qcu q5= new Qcu("What is a horse?",n2,c4,f4);
    Question_noti qn1= new Question_noti(n1,2);//nbadal hadoo
    Question_noti qn2= new Question_noti(n2,2);//
    Question_noti qn []= {qn1,qn2};
    Quiz quizzzl = new Quiz("quizzzl","23/06/2019","24/06/2019",qn);

    public void add_notion()
    {
        Notion n3 = new Notion((nouv_notion.getText()) );
        bac.add_notion(n3);
        notionlv.getItems().add(n3.getNom());
    }
    public void add_quiz()
    {
        Question_noti qn3= new Question_noti(n1,Integer.parseInt(nbmath.getValue().toString()));
        Question_noti qn4= new Question_noti(n2,Integer.parseInt(nbeng.getValue().toString()));
        Question_noti qnn []= {qn3,qn4};
        Quiz quizzwi = new Quiz(nomquiz.getText(),datedb.getText(),datefn.getText(),qnn);
        bac.add_quiz(quizzwi);
        affichquiz.setText(quizzwi.afficher());
        quizlv.getItems().add(quizzwi.getNom());

    }
    public void add_app()
    {
        String aff;
        Apprenant apprnnt = new Apprenant(nom_app.getText(), prenom_app.getText(), date_naiss_app.getText(), adresse_app.getText());
        bac.add_apprenant(apprnnt);
        System.out.println(bac.afficher_app());
        aff = bac.afficher_app();
        app_afficher.setText(aff);



    }

    public void deconnecter(ActionEvent event) throws IOException
    {


        Parent tableViewParent = FXMLLoader.load(getClass().getResource("QuizZzl.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);

        //This line gets the Stage information
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();

        window.setScene(tableViewScene);
        window.show();
    }

    @SuppressWarnings("Duplicates")
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        form.ajout_app(a1);
        form.ajout_app(a2);
        bac.add_notion(n1);
        bac.add_notion(n2);
        for (int i=0; i<bac.get_Notions().size();i++){
            notionlv.getItems().add((bac.get_Notions().get(i)).getNom());
        }
        bac.add_quiz(quizzzl);
        for (int i=0; i<bac.get_Quiz().size();i++){
            quizlv.getItems().add((bac.get_Quiz().get(i)).getNom());
        }
        nbeng.getItems().addAll(0,1,2);
        nbmath.getItems().addAll(0,1,2,3);
    }
}

